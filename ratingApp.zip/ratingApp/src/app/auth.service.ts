import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  user = new BehaviorSubject<string | null>(null);
  user$ = this.user.asObservable();
  loggedIn = new BehaviorSubject<boolean | null>(false);
  isLoggedIn$ = this.user.asObservable();

  dashboard = this.user.asObservable();
  profile = this.user.asObservable();
  logIn(username: string, log: boolean) {
    this.user.next(username);
    this.loggedIn.next(log);
    localStorage.setItem('user', username);
    localStorage.setItem('loggedIn', JSON.stringify(true));
  }

  logOut() {
    this.user.next(null);
    localStorage.removeItem('user');
    localStorage.removeItem('loggedIn');
  }
  constructor() {}
}
