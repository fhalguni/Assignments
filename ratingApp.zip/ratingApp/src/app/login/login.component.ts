import { Component } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  constructor(private auth: AuthService) {}

  logIn() {
    this.auth.logIn('Ashwini', true);
  }
  logOut() {
    this.auth.logOut();
  }
}
