import { Component, Output, EventEmitter } from '@angular/core';
import { TaskService } from '../../module/task/task.service';
import { Tasks, Status } from '../../module/task/task.model';
@Component({
  selector: 'app-share',
  standalone: false,
  providers: [TaskService],
  templateUrl: './share.component.html',
  styleUrl: './share.component.css',
})
export class ShareComponent {
 
}
