import { Component } from '@angular/core';
import { Tasks } from './module/task/task.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',

  standalone: false,
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'TaskManagement';

  newTask!: Tasks;

  getNewTask(task: Tasks) {
    this.newTask = task;
  }
}
