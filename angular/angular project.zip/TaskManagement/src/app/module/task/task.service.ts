import { Injectable } from '@angular/core';
import { Status, Tasks } from '../task/task.model';

@Injectable({
  providedIn: 'root',
})
export class TaskService {
  tasks: Tasks[] = [
    {
      id: 1,
      name: 'Complete project report',
      status: Status.In_Progress,
      priority: 'High',
    },
    {
      id: 2,
      name: 'Schedule team meeting',
      status: Status.Pending,
      priority: 'Medium',
    },
    {
      id: 3,
      name: 'Review code',
      status: Status.Completed,
      priority: 'Low',
    },
    {
      id: 4,
      name: 'Update documentation',
      status: Status.Pending,
      priority: 'High',
    },
  ];

  constructor() {}

  displayList() {
    this.tasks.forEach((t) =>
      console.log(`name:${t.name} status:${t.status} priority:${t.priority}`)
    );
  }

  updateStatus(id: number, newStatus: Status): Tasks[] {
    let result = this.tasks.some((t) => t.id === id);
    if (!result) {
      console.log('No task found');
    } else {
      this.tasks.forEach((t) => {
        if (t.id === id) {
          t.status = newStatus;
        }
      });
    }
    return this.tasks;
  }
  deleteTask(id: number): Tasks[] {
    let result = this.tasks.some((t) => t.id === id);
    if (!result) {
      console.log('No task found');
    } else {
      this.tasks.splice(
        this.tasks.findIndex((t) => t.id === id),
        1
      );
    }
    return this.tasks;
  }

  addTask(task: Tasks) {
    this.tasks.push(task);
  }
}
