export enum Status {
  Pending = 'Pending',
  In_Progress = 'In-Progress',
  Completed = 'Completed',
}

export interface Tasks {
  id: number;
  name: string;
  status: Status;
  priority: 'High' | 'Medium' | 'Low';
}
