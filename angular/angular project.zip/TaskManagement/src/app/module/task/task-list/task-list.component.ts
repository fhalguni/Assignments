import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { TaskService } from '../task.service';
import { Tasks, Status } from '../task.model';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css'],
  standalone: false,
})
export class TaskListComponent implements OnChanges {
  @Input({ required: true }) newTask!: Tasks;
  tasks: Tasks[];
  status: Status = Status.Completed;
  constructor(public taskService: TaskService) {
    this.tasks = this.taskService.tasks;
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['newTask'] && changes['newTask'].currentValue) {
      this.taskService.addTask(this.newTask);
    }
  }
}
