import { Component, EventEmitter, Output } from '@angular/core';
import { TaskService } from '../task.service';
import { Status, Tasks } from '../task.model';
@Component({
  selector: 'app-task-create',
  standalone: false,
  providers: [TaskService],
  templateUrl: './task-create.component.html',
  styleUrl: './task-create.component.css',
})
export class TaskCreateComponent {
  @Output() select = new EventEmitter<Tasks>();

  task1: Tasks = {
    id: 5,
    name: 'Report Generate',
    status: Status.Pending,
    priority: 'High',
  };

  getNewTask() {
    this.select.emit(this.task1);
  }
}
