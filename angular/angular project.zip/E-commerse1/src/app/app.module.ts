import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthModule } from './auth/auth.module';
import { NotFoundComponent } from './pages/not-found/not-found.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserRoutingModule } from './user/user-routing.module';
import { OrderRoutingModule } from './order/order-routing.module';
import { RouterModule } from '@angular/router';
import { ProductRoutingModule } from './product/product-routing.module';
import { CustomePipePipe } from './custome-pipe.pipe';
import { MaskPipePipe } from './mask-pipe.pipe';

@NgModule({
  declarations: [AppComponent, NotFoundComponent, CustomePipePipe, MaskPipePipe],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    UserRoutingModule,
    OrderRoutingModule,
    RouterModule,
    ProductRoutingModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
