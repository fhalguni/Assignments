import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'customePipe',
  standalone: false,
})
export class CustomePipePipe implements PipeTransform {
  transform(name: string): string {
    return name.split('').reverse().join('');
  }
}
