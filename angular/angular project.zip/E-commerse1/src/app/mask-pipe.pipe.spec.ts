import { MaskPipePipe } from './mask-pipe.pipe';

describe('MaskPipePipe', () => {
  it('create an instance', () => {
    const pipe = new MaskPipePipe();
    expect(pipe).toBeTruthy();
  });
});
