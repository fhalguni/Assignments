import { Component } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { Role } from '../auth/role.enum';

@Component({
  selector: 'app-user',
  standalone: false,
  templateUrl: './user.component.html',
  styleUrl: './user.component.css',
})
export class UserComponent {
  // userLogIn() {
  //   this.auth.userLogInForProfile(Role.Admin);
  // }
  constructor(private auth: AuthService) {}
}
