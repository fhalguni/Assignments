import { Component } from '@angular/core';
import { AuthService } from '../../auth/auth.service';
import { FormControl, FormGroup } from '@angular/forms';
import { Role } from '../../auth/role.enum';

@Component({
  selector: 'app-login',
  standalone: false,

  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  constructor(private auth: AuthService) {}
  myForm = new FormGroup({
    name: new FormControl(''),
    email: new FormControl(''),
    password: new FormControl(''),
  });

  onSubmit() {
    this.auth.userLogInForProfile(Role.Customer);
  }
}
