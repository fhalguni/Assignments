import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'maskPipe',
  standalone: false,
})
export class MaskPipePipe implements PipeTransform {
  transform(value: string): string {
    if (!value) {
      return '';
    }
    const visibleDigits = 4;
    const maskedSection = value.slice(0, -visibleDigits).replace(/./g, '*');
    const visibleSection = value.slice(-visibleDigits);
    return `${maskedSection}${visibleSection}`;
  }
}
