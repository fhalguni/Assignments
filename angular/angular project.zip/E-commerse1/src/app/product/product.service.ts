import { Injectable } from '@angular/core';
import { Product } from './products.model';
@Injectable({
  providedIn: 'root',
})
export class ProductService {
  constructor() {}

  products: Product[] = [
    { id: 1, name: 'Wireless Earbuds', price: 2000, category: 'Electronics' },
    { id: 2, name: 'Running Shoes', price: 4500, category: 'Footwear' },
    { id: 3, name: 'Smartwatch', price: 6000, category: 'Wearables' },
    { id: 4, name: 'Coffee Maker', price: 3500, category: 'Home' },
    { id: 5, name: 'Bluetooth Speaker', price: 3000, category: 'Electronics' },
    { id: 6, name: 'Fitness Tracker', price: 2500, category: 'Wearables' },
    { id: 7, name: 'Laptop Stand', price: 1500, category: 'Accessories' },
    { id: 8, name: 'Gaming Mouse', price: 2000, category: 'Electronics' },
    { id: 9, name: 'Desk Lamp', price: 1200, category: 'Home' },
    { id: 10, name: 'Water Bottle', price: 800, category: 'Accessories' },
  ];

  cart: Product[] = [];
  displayProducts() {
    this.products.forEach((p) => {
      return p;
    });
  }

  addNewProduct(product: Product) {
    this.products.push(product);
  }

  addToCart(id: number) {
    const result = this.products.some((p) => p.id === id);

    if (!result) {
      console.log('The product not found');
    } else {
      const p = this.products.findIndex((p) => p.id === id);
      this.cart.push(this.products[p]);
    }
  }
  deleteProduct(id: number) {
    const result = this.products.some((p) => p.id === id);

    if (!result) {
      console.log('The product not found');
    } else {
      this.products.splice(
        this.products.findIndex((p) => p.id === id),
        1
      );
    }
  }
}
