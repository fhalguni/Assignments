import { Component, EventEmitter, Output } from '@angular/core';
import { ProductService } from '../product.service';
import { Product } from '../products.model';
import { findIndex } from 'rxjs';
import { OrderService } from '../../order/order.service ';
@Component({
  selector: 'app-product-list',
  standalone: false,

  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css',
})
export class ProductListComponent {
  products: Product[] = [];

  constructor(
    private productService: ProductService,
    private orderService: OrderService
  ) {
    this.products = productService.products;
  }
  displayProduct() {
    this.productService.displayProducts();
  }

  product: Product = {
    id: 11,
    name: 'abcd',
    price: 8000,
    category: 'pqrs',
  };
  addProduct(product: Product) {
    return this.productService.addNewProduct(product);
  }

  addToCart(id: number) {
    alert('Product added successfully');

    const p = this.products.find((p) => p.id === id)!;
    this.orderService.addOrder(p);

    console.log(this.orderService.products);
  }
  deleteProduct(id: number) {
    return this.productService.deleteProduct(id);
  }
}
