import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Role } from './role.enum';
@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor(private route: Router) {
    localStorage.setItem('isLoggedIn', 'false');
  }

  userLogIn(role: Role) {
    localStorage.setItem(
      'isLoggedIn',
      JSON.stringify({
        isLoggedIn: true,
        role: role,
      })
    );

    this.route.navigate(['/orders']);
  }

  userLogInForProfile(role: Role) {
    localStorage.setItem(
      'isLoggedIn',
      JSON.stringify({
        isLoggedIn: true,
        role: role,
      })
    );

    this.route.navigate(['/user/profile']);
  }
  userLogOut() {
    localStorage.setItem('isLoggedIn', 'false');
    localStorage.setItem('role', '---');
    this.route.navigate(['/user/register']);
  }
  isAuthenticated(roles: Role[]) {
    const data = JSON.parse(localStorage.getItem('isLoggedIn')!);

    if (!data) {
      alert('Login First');
      this.route.navigate(['/user/register']);
      return false;
    } else {
      if (!data['isLoggedIn']) {
        alert('Login First');
        this.route.navigate(['/user/register']);
        return false;
      } else {
        if (roles.includes(data['role'])) {
          return true;
        } else {
          alert(`${roles}  have  only access`);
          return false;
        }
      }
    }
  }
}
