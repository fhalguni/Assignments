import {
  ActivatedRouteSnapshot,
  CanActivate,
  CanActivateChild,
  CanActivateFn,
  GuardResult,
  MaybeAsync,
  RouterStateSnapshot,
} from '@angular/router';
import { AuthService } from './auth.service';
import { Role } from './role.enum';
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root',
})
export class CustomerGuard implements CanActivate, CanActivateChild {
  constructor(private authServise: AuthService) {}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    return this.authServise.isAuthenticated([Role.Customer, Role.Admin]);
  }

  canActivateChild(
    childRoute: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    return this.authServise.isAuthenticated([Role.Customer, Role.Admin]);
  }
}
