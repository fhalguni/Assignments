import { Component } from '@angular/core';

@Component({
  selector: 'app-order-detail',
  standalone: false,
  
  templateUrl: './order-detail.component.html',
  styleUrl: './order-detail.component.css'
})
export class OrderDetailComponent {

}
