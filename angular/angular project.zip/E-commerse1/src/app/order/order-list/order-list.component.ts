import { Component } from '@angular/core';
import { AuthService } from '../../auth/auth.service';
import { OrderService } from '../order.service ';
interface Product {
  name: string;
  category: string;
  price: number;
}
@Component({
  selector: 'app-order-list',
  standalone: false,

  templateUrl: './order-list.component.html',
  styleUrl: './order-list.component.css',
})
export class OrderListComponent {
  orders: Product[] = [];
  constructor(private auth: AuthService, private orderService: OrderService) {
    this.orders = orderService.products;
  }

  logOut() {
    this.auth.userLogOut();
  }
  product: Product = {
    name: 'Headphone',
    category: 'Electronics',
    price: 3000,
  };

  addOrder(product: Product) {
    return this.orderService.addOrder(product);
  }

  deleteOrder(name: string) {
    return this.orderService.deleteOrder(name);
  }
}
