import { Injectable } from '@angular/core';
interface Product {
  name: string;
  category: string;
  price: number;
}
@Injectable({
  providedIn: 'root',
})
export class OrderService {
  products: Product[] = [
    {
      name: 'Bamboo Watch',
      category: 'Accessories',
      price: 65,
    },
    {
      name: 'Black Watch',
      category: 'Accessories',
      price: 72,
    },
  ];

  addOrder(order: Product) {
    this.products.push(order);
  }

  deleteOrder(name: string) {
    const result = this.products.some((p) => p.name === name);

    if (!result) {
      console.log('The product not found');
    } else {
      this.products.splice(
        this.products.findIndex((p) => p.name === name),
        1
      );
    }
  }
}
