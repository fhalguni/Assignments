import { Injectable, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OrderListComponent } from './order-list/order-list.component';
import { OrderDetailComponent } from './order-detail/order-detail.component';
import { CustomerGuard } from '../auth/customer.guard';
import { AdminGuard } from '../auth/admin.guard';

const route: Routes = [
  {
    path: '',
    component: OrderListComponent,
    canActivate: [CustomerGuard],
  },
  {
    path: 'order-details',
    component: OrderDetailComponent,
    canActivate: [CustomerGuard],
  },
];
@NgModule({
  imports: [RouterModule.forChild(route)],
  exports: [RouterModule],
})
export class OrderRoutingModule {}
