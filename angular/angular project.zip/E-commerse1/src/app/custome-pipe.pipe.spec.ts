import { CustomePipePipe } from './custome-pipe.pipe';

describe('CustomePipePipe', () => {
  it('create an instance', () => {
    const pipe = new CustomePipePipe();
    expect(pipe).toBeTruthy();
  });
});
