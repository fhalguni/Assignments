import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
interface Course {
  id: number;
  name: string;
  desc: string;
}
@Component({
  selector: 'app-courses',
  standalone: false,

  templateUrl: './courses.component.html',
  styleUrl: './courses.component.css',
})
export class CoursesComponent implements OnInit {
  @Input() id!: number;
  @Output() send = new EventEmitter<Course>();
  c1: Course = {
    id: 1,
    name: 'Angular',
    desc: 'This is Angular Course',
  };

  c2: Course = {
    id: 2,
    name: 'TypeScript',
    desc: 'This is TypeScript Course',
  };
  c3: Course = {
    id: 3,
    name: 'JavaScript',
    desc: 'This is JavaScript Course',
  };
  course: Course[] = [this.c1, this.c2, this.c3];
  selectedCource?: Course;
  constructor(private routes: ActivatedRoute) {}

  ngOnInit(): void {
    this.routes.paramMap.subscribe((params) => {
      this.id = Number(params.get('id'));
      this.selectedCource = this.course.find((c) => this.id === c.id);
    });
  }

  sendData(c: Course) {
    if (this.id === c.id) {
      this.send.emit(c);
    }
  }
}
