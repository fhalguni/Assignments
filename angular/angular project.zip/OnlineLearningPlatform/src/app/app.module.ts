import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { CoursesComponent } from './courses/courses.component';
import { ProfileComponent } from './profile/profile.component';
import { LoginModule } from './login/login.module';
import { UserLoginRoutingModule } from './login/login-routing.module';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CoursesComponent,
    ProfileComponent,
  ],
  imports: [BrowserModule, AppRoutingModule, UserLoginRoutingModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
