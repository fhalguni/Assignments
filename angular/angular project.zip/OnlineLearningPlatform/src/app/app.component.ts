import { Component } from '@angular/core';
interface Course {
  id: number;
  name: string;
  desc: string;
}
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css',
})
export class AppComponent {
  course!: Course;
  getData(c: Course) {
    this.course = c;
  }
}
