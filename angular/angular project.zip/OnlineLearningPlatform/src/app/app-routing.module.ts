import { NgModule } from '@angular/core';
import { ExtraOptions, RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { CoursesComponent } from './courses/courses.component';
import { ProfileComponent } from './profile/profile.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
  },
  {
    path: 'courses/:id',
    component: CoursesComponent,
  },

  {
    path: 'profile',
    component: ProfileComponent,
  },
  {
    path: '',
    loadChildren: () => {
      return import('./login/login.module').then((m) => m.LoginModule);
    },
  },
];

const routeOption: ExtraOptions = {
  bindToComponentInputs: true,
};

@NgModule({
  imports: [RouterModule.forRoot(routes, routeOption)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
