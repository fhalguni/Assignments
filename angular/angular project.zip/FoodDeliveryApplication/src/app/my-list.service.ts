import { Injectable } from '@angular/core';

interface Food {
  id: number;
  name: string;
  price: number;
}

@Injectable({
  providedIn: 'platform',
})
export class MyListService {
  constructor() {}

  foodArray: Food[] = [
    { id: 1, name: 'Apple', price: 100 },
    { id: 2, name: 'Banana', price: 200 },
    { id: 3, name: 'Carrot', price: 300 },
    { id: 4, name: 'Donut', price: 400 },
    { id: 5, name: 'Tomato', price: 30 },
  ];

  Cart: Food[] = [];
  displayList(): Food[] {
    return this.foodArray;
  }

  displayCartItems(): Food[] {
    return this.Cart;
  }

  addtoCart(id: number) {
    let result = this.foodArray.some((food) => food.id === id);
    if (!result) {
      console.log('No Food found');
    } else {
      this.foodArray.forEach((food) => {
        if (food.id === id) {
          this.Cart.push(food);
        }
      });
    }
  }

  removeFromCart(id: number) {
    const index = this.Cart.findIndex((food) => food.id === id);
    if (index === -1) {
      console.log('No food item found');
    } else {
      this.Cart.splice(index, 1);
    }
  }

  calculateTotalPrice() {
    return this.Cart.reduce((acc, curr) => (acc = acc + curr.price), 0);
  }
}
