import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FoodItemsComponent } from './food-items/food-items.component';
import { MyListService } from './my-list.service';

@Component({
  selector: 'app-root',
  imports: [FoodItemsComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {}
