import { Component } from '@angular/core';

import { NgFor } from '@angular/common';
import { MyListService } from '../my-list.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-food-items',
  imports: [NgFor, FormsModule],
  templateUrl: './food-items.component.html',
  styleUrl: './food-items.component.css',
})
export class FoodItemsComponent {
  food: [] = [];
  constructor(public service: MyListService) {}

  message = '';
  imagePath() {
    return 'favicon.ico';
  }
}
